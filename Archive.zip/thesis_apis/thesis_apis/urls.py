"""thesis_apis URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from thesis_app.views import ProfileDetails, ProfileList, PatientList, PatientDetails, ScanList, ScanDetails, ScanViewSet, ProfilePatients, PatientScans
from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path("admin/", admin.site.urls),
    path("profiles/", ProfileList.as_view()),
    path("profile/<int:pk>", ProfileDetails.as_view()),
    path("profile/<int:pk>/patients", ProfilePatients.as_view()),

    
    path("patients/", PatientList.as_view()),
    path("patient/<int:pk>", PatientDetails.as_view()),
    path("patient/<int:pk>/scans", PatientScans.as_view()),

    path("scans/", ScanList.as_view()),
    path("scan/<int:pk>", ScanDetails.as_view()),
    
    path("scanNew/", ScanViewSet.as_view()),

    # path("show_patient_profile/<str:id>", views.show_patient_profile),
    # path("add_patient", views.add_patient),
    # path("add_radiologist", views.add_radiologist),
    # path("add_scan/<str:id>", views.add_scan),
    # path("image_upload_view", views.image_upload_view),
    # path("add_radiologist", views.add_radiologist),
    # path("add_radiologist", views.add_radiologist),
    # path("add_radiologist", views.add_radiologist),
    # path("add_radiologist", views.add_radiologist),
    # path("add_radiologist", views.add_radiologist),
    # path("add_radiologist", views.add_radiologist),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
