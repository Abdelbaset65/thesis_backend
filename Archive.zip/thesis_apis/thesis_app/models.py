from contextlib import nullcontext
from email.policy import default
from django.db import models

# Create your models here.
 
class Radiologist(models.Model):
    name = models.CharField(max_length=100)
    id = models.AutoField(primary_key=True)
    email = models.EmailField(max_length=100, unique=True)
    mobile_number = models.CharField(max_length=10, unique=True)
    national_id = models.CharField(max_length=10, unique=True)
    password = models.CharField(max_length=100, default="123456")
    
    def __str__(self):
        return self.name
    


class Patient(models.Model):
    name = models.CharField(max_length=100)
    id = models.AutoField(primary_key=True)
    mobile_number = models.CharField(max_length=11)
    national_id = models.CharField(max_length=16)
    radiologist = models.ForeignKey(Radiologist, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.name
    

class Scan(models.Model):
    
    input_image = models.ImageField(upload_to='images/input/', blank=True, null=True)
    output_image = models.ImageField(upload_to='images/output/', blank=True, null=True)
    datetime = models.DateTimeField(auto_now_add=True)
    patient =  models.ForeignKey(Patient, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.datetime)

