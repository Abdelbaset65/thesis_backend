from unicodedata import name
from django.http import HttpResponse
import json
from django.shortcuts import render
from .models import Patient, Radiologist, Scan
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
from django import forms
from rest_framework import generics
from .serializers import RadiologistSerializer, PatientSerializer, ScanSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status


class ProfileList(generics.ListCreateAPIView):
    queryset = Radiologist.objects.all()
    serializer_class = RadiologistSerializer


class ProfileDetails(generics.RetrieveUpdateDestroyAPIView):
    queryset = Radiologist.objects.all()
    serializer_class = RadiologistSerializer

class ProfilePatients(APIView):
    def get(self, request, pk):

 
        patient_obj = Patient.objects.filter(radiologist=pk)
        if patient_obj:
            return Response(PatientSerializer(patient_obj, many=True).data, status.HTTP_200_OK)
        return Response(PatientSerializer(patient_obj).errors, status.HTTP_400_BAD_REQUEST)
    
class PatientScans(APIView):
    def get(self, request, pk):

 
        scan_obj = Scan.objects.filter(patient=pk)
        if scan_obj:
            return Response(ScanSerializer(scan_obj, many=True).data, status.HTTP_200_OK)
        return Response(ScanSerializer(scan_obj).errors, status.HTTP_400_BAD_REQUEST)

class PatientList(generics.ListCreateAPIView):
    queryset = Patient.objects.all()
    serializer_class = PatientSerializer


class PatientDetails(generics.RetrieveUpdateDestroyAPIView):
    queryset = Patient.objects.all()
    serializer_class = PatientSerializer


class ScanList(generics.ListCreateAPIView):
    queryset = Scan.objects.all()
    serializer_class = ScanSerializer
    


class ScanDetails(generics.RetrieveUpdateDestroyAPIView):
    queryset = Scan.objects.all()
    serializer_class = ScanSerializer



class ScanViewSet(APIView):
    def get(self, request):
        scans = Scan.objects.all()
        serializer = ScanSerializer(scans, many=True)
        return Response(serializer.data)
    
    def post(self, request):
        serializer = ScanSerializer(data=request.data)
        if serializer.is_valid():
            # serializer.data["output_image"] = process(serializer.data['input_image'])
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



















# def show_profile(request, id):
#     if request.method == "GET":
#         try:
#             radiologist = Radiologist.objects.get(id=id)
#             patients = Patient.objects.filter(radiologist_id=id)
#             patients_list = [[patient.name, patient.id] for patient in patients]
#             response = json.dumps({ 'success':True, 'radiologist' :{ 'name': radiologist.name, 'id': radiologist.id, 
#                                    'email': radiologist.email, 'mobile_number': radiologist.mobile_number, 
#                                    'national_id': radiologist.national_id, 'patints': patients_list} })
#         except:
#             response = json.dumps({ 'success':False, 'message' : "Radiologist does not exist" })
            
#     return HttpResponse(response, content_type="application/json")


# @csrf_exempt
# def add_radiologist(request):
#     if request.method == "POST":
#         payload  = json.loads(request.body)
#         name = payload['name']
#         mobile = payload['mobile']
#         national_id = payload['national_id']
#         email = payload['email']
#         password = payload ['password']
#         radiologist = Radiologist(name=name, mobile_number=mobile, national_id=national_id, email=email, password=password)

#         try:
#             radiologist.save()
#             response = json.dumps({ 'success':True, 'message' : "Radiologist added successfully" , 'id': radiologist.id})
#         except:
#             response = json.dumps({ 'success':False, 'message' : "Radiologist already exists" })
#     return HttpResponse(response, content_type="application/json")


# @csrf_exempt
# def add_patient(request):
#     if request.method == "POST":
#         payload  = json.loads(request.body)
#         name = payload['name']
#         mobile = payload['mobile']
#         national_id = payload['national_id']
#         radiologist_id = payload['radiologist_id']

#         patient = Patient(name=name, mobile_number=mobile, national_id=national_id, radiologist_id=radiologist_id)
#         try:
#             patient.save()
#             response = json.dumps({ 'success':True, 'message' : "Patient added successfully" , 'id': patient.id})
#         except:
#             response = json.dumps({ 'success':False, 'message' : "Patient already exists" })
#     return HttpResponse(response, content_type="application/json")


# @csrf_exempt
# def show_patient_profile(request, id):
#     if request.method == "GET":
#         try:

#             patient = Patient.objects.get(id=id)
#             scans = Scan.objects.filter(patient_id=id)
#             scans_list = [[scan.datetime,scan.id, scan.url, scan.result_url] for scan in scans]
#             response = json.dumps({ 'success':True, 'patient' :{ 'name' : patient.name, 'id' : patient.id,
#                                                                 'mobile': patient.mobile_number,
#                                                                 'scans': scans_list} })
#         except:
#             response = json.dumps({ 'success':False, 'message' : "Patient does not exist" })
            
#     return HttpResponse(response, content_type="application/json")


# @csrf_exempt
# def add_scan(request, id):
#     if request.method == "POST":
#         # payload  = json.loads(request.body)
#         url = request.FILES['scan_image']
#         # patient_id = request.FILES['patient_id']
#         print(url)
        
#         scan = Scan(str(url), patient_id=id)
#         print(str(scan))
#         try:
#             scan.save()
#             print("saved")
#             response = json.dumps({ 'success':True, 'message' : "Scan added successfully" , 'id': scan.id, 'url': scan.url})
#         except:
#             response = json.dumps({ 'success':False, 'message' : "failed to upload" })
#     return HttpResponse(response, content_type="application/json")

        
# # @csrf_exempt
# # def image_upload_view(request):
# #     """Process images uploaded by users"""
# #     if request.method == 'POST':
# #         # form = ScanForm(request.POST, request.FILES)
# #         print("post  ",request.POST)
# #         print("FILES  ",request.FILES)

# #         if form.is_valid():
# #             form.save()
# #             return HttpResponse('image upload success')

    
# #     return HttpResponse('image upload faliure')
