from .models import Patient, Radiologist, Scan
from rest_framework import serializers




class RadiologistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Radiologist
        fields = '__all__'
        
class PatientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Patient
        fields = '__all__'
        
class ScanSerializer(serializers.ModelSerializer):
    input_image = serializers.ImageField()
    output_image = serializers.ImageField(read_only=True)

    class Meta:
        model = Scan
        fields = ['id', 'input_image', 'output_image', 'datetime', 'patient']